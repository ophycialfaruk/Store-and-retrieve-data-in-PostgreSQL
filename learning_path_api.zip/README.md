# Learning Path API

## Setup Instructions

1. Install PostgreSQL and Node.js
2. Create a database named `learning_path_db`
3. Run the SQL script in `sql/create_users_table.sql`
4. Update your PostgreSQL password in `config/db.js`
5. Install project dependencies:
   ```bash
   npm install
   ```
6. Start the server:
   ```bash
   npm start
   ```
7. Test API endpoints using Postman or any API testing tool.

## API Endpoints

- `GET /users` - Get all users
- `GET /users/:id` - Get a user by ID
- `POST /users` - Create a new user
- `PUT /users/:id` - Update a user
- `DELETE /users/:id` - Delete a user
